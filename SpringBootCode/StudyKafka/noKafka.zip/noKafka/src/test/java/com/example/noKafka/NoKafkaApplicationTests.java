package com.example.noKafka;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NoKafkaApplicationTests {

	@Test
	void contextLoads() {
	}

}
